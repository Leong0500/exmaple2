<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['namespace' => 'Site'], function () {

    Route::get('/','HomeController@showHomePage')->name('site.index');
    Route::get('about','HomeController@showAboutUs')->name('site.about');
    Route::get('contact-us','HomeController@showContactUs')->name('site.contact');
    Route::get('solutions','HomeController@showSolutions')->name('site.solution');
    Route::get('alliance','HomeController@showAlliance')->name('site.alliance');
    Route::get('careers','HomeController@showCareer')->name('site.career');
    Route::get('career-detail','HomeController@showCareerDetail')->name('site.career.detail');
    Route::get('clients','HomeController@showClients')->name('site.client');
    Route::get('thank-you','HomeController@thankYou')->name('site.thank-you');


    Route::get('career/detail/data-capturer','HomeController@showCareerOne')->name('site.career.1');
    Route::get('career/detail/it-engineer','HomeController@showCareerTwo')->name('site.career.2');
    Route::get('career/detail/marketing-specialist','HomeController@showCareerThree')->name('site.career.3');
    Route::get('career/detail/system-engineer','HomeController@showCareerFour')->name('site.career.4');
    Route::get('career/detail/sales-account-manager','HomeController@showCareerFive')->name('site.career.5');
    Route::get('career/detail/accountant','HomeController@showCareerSix')->name('site.career.6');

    Route::post('enquiry','EnquiryController@storeEnquiry')->name('site.enquiry');
});
