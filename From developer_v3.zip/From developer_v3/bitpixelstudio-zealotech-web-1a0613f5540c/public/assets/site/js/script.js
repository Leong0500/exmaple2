$(document).ready(function (){

    let mobileMenuOpen = $('#mobileMenu');
    let mobileMenuClose = $('#mobileMenuClose');
    let mobileMenu = $('.mobile__menu--wrapper');
    let body = $('body');

    mobileMenuOpen.on('click',function () {
        mobileMenu.removeClass('d-none');
        body.addClass('no__scroll')
    });

    mobileMenuClose.on('click',function (){
       mobileMenu.addClass('d-none');
        body.removeClass('no__scroll')
    });

});
