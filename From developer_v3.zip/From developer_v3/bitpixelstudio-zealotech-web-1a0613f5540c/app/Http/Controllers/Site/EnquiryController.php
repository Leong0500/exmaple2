<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;
use App\Http\Requests\EnquiryRequest;

use App\Model\Enquiry;


class EnquiryController extends Controller
{


    public function storeEnquiry(EnquiryRequest $request)
    {
        $enquiry = new Enquiry;
        $enquiry->name = $request->input('name');
        $enquiry->email = $request->input('email');
        $enquiry->phone = $request->input('phone');
        $enquiry->message = $request->input('message');
        $enquiry->save();

        $request->session()->flash('message', 'The enquiry was sent successfully! Thank You.');
        return redirect()->route('site.thank-you');
    }


}
