<?php

namespace App\Http\Controllers\Site;

use App\Http\Controllers\Controller;


class HomeController extends Controller
{

    public function showHomePage()
    {
        return view('site.index');
    }

    public function showAboutUs()
    {
        return view('site.about');
    }

    public function showContactUs()
    {
        return view('site.contact');
    }

    public function showCareer()
    {
        return view('site.career');
    }

    public function showCareerDetail()
    {
        return view('site.career-detail');
    }

    public function showAlliance()
    {
        return view('site.alliance');
    }

    public function showSolutions()
    {
        return view('site.solution');
    }

    public function showClients()
    {
        return view('site.client');
    }

    public function showCareerOne()
    {
        return view('site.career.1');
    }

    public function showCareerTwo()
    {
        return view('site.career.2');
    }

    public function showCareerThree()
    {
        return view('site.career.3');
    }

    public function showCareerFour()
    {
        return view('site.career.4');
    }

    public function showCareerFive()
    {
        return view('site.career.5');
    }

    public function showCareerSix()
    {
        return view('site.career.6');
    }

    public function thankYou()
    {
        return view('site.thank-you');
    }

}
