<?php

namespace App\Observers;

use App\Mail\EnquiryMail;
use App\Model\Enquiry;
use Illuminate\Support\Facades\Mail;

class EnquiryObserver
{

    public function created(Enquiry $enquiry)
    {
        $email = 'zCare@zealotechsolution.com';

        Mail::to($email)
            ->send(new EnquiryMail($enquiry->name, $enquiry->email, $enquiry->phone, $enquiry->message));
    }

}
