<php
function getIPAddress() {  
    //whether ip is from the share internet  
     if(!emptyempty($_SERVER['HTTP_CLIENT_IP'])) {  
                $ip = $_SERVER['HTTP_CLIENT_IP'];  
        }  
    
    //whether ip is from the proxy  
    elseif (!emptyempty($_SERVER['HTTP_X_FORWARDED_FOR'])) {  
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];  
     }  
//whether ip is from the remote address  
    else{  
             $ip = $_SERVER['REMOTE_ADDR'];  
     }  
     return $ip;  
}  
$ip = getIPAddress();

$apiURL = 'https://freegeoip.app/json/'.$ip; 

$ch = curl_init($apiURL); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
$apiResponse = curl_exec($ch); 
curl_close($ch);

$ipInfo = json_decode($apiResponse, true); 

if(!empty($ipInfo))
{
$country_code = $ipInfo['country_code'];
header ("Location: https://zealotechsolution.com/".country_code);
}

?>