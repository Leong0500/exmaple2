@extends('site.layouts.app')
@section('pageTitle', 'Home')
@php
    $menuTag = 'home';
@endphp


@section('content')
    <section>
        <div class="container-fluid px-0">
            <div class="banner__wrapper">

                <img src="{{ asset('assets/site/images/banner@2x.png') }}" alt="main_banner"/>


                <div class="overlay__wrapper--home">
                    <div class="overlay__content--home">
                        <h1 class="overlay__title--home" style="line-height: 1.5">
                            EMPOWER YOUR BUSINESS.<br>
                            ELEVATE YOUR <span class="font__yellow">FUTURE</span>.
                        </h1>
                        <div class="overlay__text--home">
                            Zealotech specialises in IT solutions that take <br>businesses to the next level.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="inner__wrapper section__padding">
                <div class="section__wrapper--home">
                    <div class="section__title--home">
                        About Us
                    </div>
                    <div class="section__text--home">
                        Zealotech Solution is an IT solutions provider based in Kuala Lumpur, Malaysia and Singapore. Founded by a passionate team of veteran engineers with over 25 years of IT industry experience, we specialise in cutting-edge IT solutions for both large and small businesses.
                    </div>

                    <a href="{{ route('site.about') }}" class="section__btn-home">More <i class="fas fa-angle-right"></i></a>

                </div>


                <div class="row">
                    <div class="col-12 col-md-4">
                        <div class="section__home--about">
                            <div class="section__home--about-img">

                                <img src="{{ asset('assets/site/images/icons/about_1@2x.png') }}" alt="a1" />

                            </div>

                            <div class="section__home--about-title">
                                WE DELIVER RESULTS
                            </div>
                            <div class="section__home--about-text">
                                On time, on budget, on brief. We will always go the extra mile to make sure that our clients’ expectations are met in absolute excellence.
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-4">
                        <div class="section__home--about">
                            <div class="section__home--about-img">

                                <img src="{{ asset('assets/site/images/icons/about_2@2x.png') }}" alt="a2" />

                            </div>

                            <div class="section__home--about-title">
                                WE ADD VALUE
                            </div>
                            <div class="section__home--about-text">
                                Everything we do is geared towards helping our clients run their businesses more efficiently and effectively, and gain a competitive edge.
                            </div>
                        </div>
                    </div>

                    <div class="col-12 col-md-4">
                        <div class="section__home--about">
                            <div class="section__home--about-img">

                                <img src="{{ asset('assets/site/images/icons/about_3@2x.png') }}" alt="a3" />

                            </div>

                            <div class="section__home--about-title">
                                WE WORK TOGETHER
                            </div>
                            <div class="section__home--about-text">
                                From day one of each project, we align our vision with the client to ensure a close understanding that sets the stage for rewarding long-term partnerships.
                            </div>
                        </div>
                    </div>
                </div>


                <div class="mt-3 text-center">
                    <a href="{{ asset('assets/site/doc/Zealotech_Solution_Company_Profile.pdf') }}" target="_blank"><img src="{{ asset('assets/site/images/pdf.png') }}" width="180px" /></a>
                </div>

            </div>
        </div>
    </section>


    <section class="bg__gradient-gray">
        <div class="container">
            <div class="inner__wrapper section__padding">
                <div class="section__wrapper--home">
                    <div class="section__title--home">
                        Solution
                    </div>
                    <div class="section__text--home">
                        We offer a wide selection of customized solutions purposed for various business needs, ably supported by our team of IT engineers always prepared to serve clients to their best capacities.
                    </div>
                </div>

                <div class="section__home--solution">
                    <div class="section__home--solution-slider" id="slider">
                        <div class="slider__item">
                            <div class="slider__item--content">
                                <div class="slider__item--img">
                                    <img src="{{ asset('assets/site/images/solution_1@2x.png') }}" alt="s1" />

                                </div>
                                <div class="slider__item--title bg__gradient-gray--reverse">
                                    <span class="font__light-gray">ENTERPRISE</span><br>
                                    <span class="font__main">ARCHITECTURE</span>
                                </div>
                            </div>
                        </div>

                        <div class="slider__item">
                            <div class="slider__item--content">
                                <div class="slider__item--img">
                                    <img src="{{ asset('assets/site/images/solution_2@2x.png') }}" alt="s2" />

                                </div>
                                <div class="slider__item--title bg__gradient-gray--reverse">
                                    <span class="font__main">CLOUD</span><br>
                                    <span class="font__light-gray">COMPUTING</span>
                                </div>
                            </div>
                        </div>

                        <div class="slider__item">
                            <div class="slider__item--content">
                                <div class="slider__item--img">
                                    <img src="{{ asset('assets/site/images/solution_3@2x.png') }}" alt="s3" />
                                </div>
                                <div class="slider__item--title bg__gradient-gray--reverse">
                                    <span class="font__light-gray">NETWORK</span><br>
                                    <span class="font__main">SECURITY</span>
                                </div>
                            </div>
                        </div>


                        <div class="slider__item">
                            <div class="slider__item--content">
                                <div class="slider__item--img">
                                    <img src="{{ asset('assets/site/images/solution_4.png') }}" alt="s4" />
                                </div>
                                <div class="slider__item--title bg__gradient-gray--reverse">
                                    <span class="font__main">DATA</span><br>
                                    <span class="font__light-gray">PROTECTION</span>
                                </div>
                            </div>
                        </div>


                        <div class="slider__item">
                            <div class="slider__item--content">
                                <div class="slider__item--img">
                                    <img src="{{ asset('assets/site/images/solution_5.png') }}" alt="s5" />
                                </div>
                                <div class="slider__item--title bg__gradient-gray--reverse">
                                    <span class="font__light-gray">DISASTER</span><br>
                                    <span class="font__main">RECOVERY</span>
                                </div>
                            </div>
                        </div>


                    </div>

                    <div class="slider__btn--wrapper">
                        <button class="btn btn-default slider-arrows slider-arrows--left sliderPrev"><i class="fa fa-angle-left"></i></button>
                        <button class="btn btn-default slider-arrows slider-arrows--right sliderNext"><i class="fa fa-angle-right"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section>
        <div class="container">
            <div class="inner__wrapper section__padding">
                <div class="section__wrapper--home mb-0">
                    <div class="section__title--home text-center">
                        Alliance
                    </div>

                    <div class="row">
                        <div class="col-md-12">
                            <div class="section__text--home text-justify">
                                To give our customers the very best solutions, we work closely with a global network of the top names within various fields of IT. These include renowned corporations such as Microsoft, Cisco, Broadcom, Nutanix, Extreme Networks, Trend Micro, Sophos, Veritas, Fortinet, Dell Technologies, Veeam, Huawei, VMWare, Kemp, Hewlett Packard Enterprise, Barracuda, Lenovo, Citrix, APC, Fireeye and more.
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-4 col-md-2 px-0 section__home--alliance-img">
                                    <img src="{{ asset('assets/site/images/alliance/Logo-01.png') }}" alt="alliance_1" />
                                </div>
                                <div class="col-4 col-md-2 px-0  section__home--alliance-img">
                                    <img src="{{ asset('assets/site/images/alliance/Logo-02.png') }}" alt="alliance_2" />
                                </div>
                                <div class="col-4 col-md-2 px-0  section__home--alliance-img">
                                    <img src="{{ asset('assets/site/images/alliance/Logo-03.png') }}" alt="alliance_3" />
                                </div>
                                <div class="col-4 col-md-2 px-0  section__home--alliance-img">
                                    <img src="{{ asset('assets/site/images/alliance/Logo-04.png') }}" alt="alliance_4" />
                                </div>
                                <div class="col-4 col-md-2 px-0  section__home--alliance-img">
                                    <img src="{{ asset('assets/site/images/alliance/Logo-05.png') }}" alt="alliance_5" />
                                </div>
                                <div class="col-4 col-md-2 px-0  section__home--alliance-img">
                                    <img src="{{ asset('assets/site/images/alliance/Logo-06.png') }}" alt="alliance_6" />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="section__padding" style="padding-bottom: 0">
        <div class="container">
            <div class="inner__wrapper">
                <div class="section__wrapper--home" style="margin-bottom: 20px">
                    <div class="section__title--home">
                        <span class="section__home--client-title position-relative">Our Clients</span>
                        <div class="section__title--divider"></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="section__home--client">
                <div class="section__home--client-box">
                    <div class="section__home--client-img">
                        <img src="{{ asset('assets/site/images/client_1@2x.png') }}" alt="c_img" />
                    </div>
                </div>

                <div class="section__home--client-box d-flex flex-wrap align-content-center">

                    <div class="home__client--box-content">
                        <div class="home__client--img">
                            <img src="{{ asset('assets/site/images/client/c_logo_1.png') }}" alt="c1" />
                        </div>
                        <div class="home__client--img">
                            <img src="{{ asset('assets/site/images/client/c_logo_2.png') }}" alt="c2" />
                        </div>
                        <div class="home__client--img">
                            <img src="{{ asset('assets/site/images/client/c_logo_3.png') }}" alt="c3" />
                        </div>
                        <div class="home__client--img">
                            <img src="{{ asset('assets/site/images/client/c_logo_4.png') }}" alt="c4" />
                        </div>
                        <div class="home__client--img">
                            <img src="{{ asset('assets/site/images/client/c_logo_5.png') }}" alt="c5" />
                        </div>
                        <div class="home__client--img">
                            <img src="{{ asset('assets/site/images/client/c_logo_6.png') }}" alt="c6" />
                        </div>
                        <div class="home__client--img">
                            <img src="{{ asset('assets/site/images/client/c_logo_7.png') }}" alt="c7" />
                        </div>
                        <div class="home__client--img">
                            <img src="{{ asset('assets/site/images/client/c_logo_8.png') }}" alt="c8" />

                        </div>
                    </div>
                </div>
            </div>
    </section>

    <section class="section__padding py-0">
        <div class="container-fluid px-0">

           <div class="home__contact--wrapper">
               <div class="section__home--contact" style="padding-left: 15%">
                   <div style="padding-top: 20%"></div>
                   <div class="section__home--contact-content" id="my_c">
                       <div class="home__contact--img">

                           <img src="{{ asset('assets/site/images/icons/marker@2x.png') }}" alt="marker" />

                       </div>
                       <div class="home__contact--text">
                           <div class="font__bold">Zealotech Solution (M) Sdn. Bhd.</div>
                           <div>
                               Unit 20-01, Level 20, Menara Geno,  Jalan<br>
                               Subang Mas, 47620 Subang Jaya,<br>
                               Selangor Darul Ehsan, Malaysia.
                           </div>
                       </div>
                   </div>

                   <div class="home__contact--divider"></div>

                   <div class="section__home--contact-content mb-5" id="sg_c">
                       <div class="home__contact--img">

                           <img src="{{ asset('assets/site/images/icons/marker@2x.png') }}" alt="marker" />

                       </div>
                       <div class="home__contact--text">
                           <div class="font__bold">Zealotech Solution Pte. Ltd.</div>
                           <div>
                               1 Tampines North Drive, 1, #06-08,<br>
                               T-Space, Singapore 528559
                           </div>
                       </div>
                   </div>
               </div>
               <div class="section__home--contact">
                   <iframe id="my" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.1452367619645!2d101.55556331487612!3d3.055780354571401!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc4d17eb12bbb9%3A0xd4622faa1aa40ec9!2sZealotech%20Solution%20(M)%20Sdn.%20Bhd.!5e0!3m2!1sen!2smy!4v1614063136052!5m2!1sen!2smy" width="100%" height="470" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                   <iframe id="sg" class="d-none" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.6758689015487!2d103.93097931487918!3d1.3711668618882291!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31da3dbae1e2aa75%3A0x279396d6a4ccd051!2sZealotech%20Solution%20Pte.%20Ltd.!5e0!3m2!1sen!2smy!4v1614175528487!5m2!1sen!2smy" width="100%" height="470" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
               </div>
           </div>

        </div>
    </section>
@endsection


@push('scripts')
    <script>
        $(document).ready(function(){
            $('#slider').slick({
                dots: false,
                infinite: true,
                autoplay:true,
                autoplaySpeed: 3500,
                arrow:true,
                slidesToShow: 3,
                slidesToScroll: 1,
                prevArrow:'.sliderPrev',
                nextArrow:'.sliderNext',
                responsive: [
                    {
                        breakpoint: 992,
                        settings: {
                            slidesToShow: 3,
                            slidesToScroll: 1,
                            infinite: true,
                            dots: true
                        }
                    },
                    {
                        breakpoint: 600,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 1
                        }
                    },
                    {
                        breakpoint: 480,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1
                        }
                    }
                ]
            });

            $('#my_c').on('click',function (){
                $('#my').removeClass('d-none');
                $('#sg').addClass('d-none');
            });

            $('#sg_c').on('click',function (){
                $('#sg').removeClass('d-none');
                $('#my').addClass('d-none');
            });

        });
    </script>
@endpush
