@extends('site.layouts.app')
@section('pageTitle', 'Solutions')
@php
    $menuTag = 'solution';
@endphp


@section('content')
    <section>
        <div class="banner__img">

            <img src="{{ asset('assets/site/images/banner_solution@2x.png') }}" alt="solution_banner" />

            <div class="overlay__wrapper--home">
                <h1 class="overlay__banner--title">
                    Solutions
                </h1>
            </div>
        </div>
    </section>

    <section class="section__padding pb-0">
        <div class="container">
            <div class="inner__wrapper">
                <div class="sub__wrapper">
                    <div class="sub__text">
                        We offer a wide selection of customized solutions purposed for various business needs, ably supported by our team of IT engineers always prepared to serve clients to their best capacities.
                    </div>
                </div>
            </div>


            <div class="inner__wrapper section__padding">
                <div class="solution__wrapper">
                    <div class="solution__img">

                        <img src="{{ asset('assets/site/images/solution_1@2x.png') }}" alt="s1" />

                    </div>
                    <div class="solution__content bg__gradient-gray--right">
                        <div class="solution__title">
                            <span class="font__light-gray">ENTERPRISE</span><br>
                            <span class="font__main">ARCHITECTURE</span>
                        </div>
                        <div class="solution__text">
                            By tapping into our expertise in enterprise architecture, businesses can effortlessly align their strategic vision and information technology. Enterprise architecture works to reduce siloed business operations, ensuring that all business units are well-synchronised in terms of communication and collaboration. This not only ensures a more efficient workflow, but also a seamless end user experience that is instrumental in building customer satisfaction.
                        </div>
                    </div>
                </div>

                <div class="solution__wrapper flex-row-reverse">
                    <div class="solution__img">

                        <img src="{{ asset('assets/site/images/solution_2@2x.png') }}" alt="s2" />

                    </div>
                    <div class="solution__content bg__gradient-gray--left">
                        <div class="solution__title">
                            <span class="font__main">CLOUD</span><br>
                            <span class="font__light-gray">COMPUTING</span>
                        </div>
                        <div class="solution__text">
                            Through the technological revolution of cloud computing, we empower small businesses to leverage on a full range of capabilities typically only large companies can afford. With just an Internet connection, SMEs can make use of the most powerful software and services on an as-needed basis, and access everything from data backup to customer relationship management systems via the Cloud.
                        </div>
                    </div>
                </div>


                <div class="solution__wrapper">
                    <div class="solution__img">

                        <img src="{{ asset('assets/site/images/solution_3@2x.png') }}" alt="s3" />

                    </div>
                    <div class="solution__content bg__gradient-gray--right">
                        <div class="solution__title">
                            <span class="font__light-gray">NETWORK</span><br>
                            <span class="font__main">SECURITY</span>
                        </div>
                        <div class="solution__text">
                            With the constant evolution of the Internet and increasing size of computer networks, network security is fast becoming essential for companies with a digital footprint. We help enterprises to implement network security measures to proactively minimise risk of unwanted incidents such as privacy spoofing, identity or information theft and so on.
                        </div>
                    </div>
                </div>

                <div class="solution__wrapper flex-row-reverse">
                    <div class="solution__img">

                        <img src="{{ asset('assets/site/images/solution_4@2x.png') }}" alt="s4" />

                    </div>
                    <div class="solution__content bg__gradient-gray--left">
                        <div class="solution__title">
                            <span class="font__main">DATA</span><br>
                            <span class="font__light-gray">PROTECTION</span>
                        </div>
                        <div class="solution__text">
                            In today’s high-tech world, data is one of the most valuable assets of any company. Loss of data from accidental deletion or cyber-attacks can be devastating for businesses, leading to loss of money, time and customers’ trust. We help businesses to safeguard against such prevalent threats through extensive data backup solutions, as well as encryption services to protect critical information from ransomware.
                        </div>
                    </div>
                </div>


                <div class="solution__wrapper">
                    <div class="solution__img">

                        <img src="{{ asset('assets/site/images/solution_5@2x.png') }}" alt="s5" />

                    </div>
                    <div class="solution__content bg__gradient-gray--right">
                        <div class="solution__title">
                            <span class="font__light-gray">DISASTER</span><br>
                            <span class="font__main">RECOVERY</span>
                        </div>
                        <div class="solution__text">
                            Be they natural or manmade, disasters can strike at any time and severely cripple any business. Recover in itself is also a highly stressful, costly and time consuming affair. However, we are able to help companies mitigate this potential risk by preparing ahead with a well-thought recovery plan. Hence, companies can have the assurance of minimal loss or disruption should the unexpected occur, operating with total peace of mind.
                        </div>
                    </div>
                </div>

            </div>

            <div class="inner__wrapper">

                <div class="bg__img position-relative" style="{{ secure_asset('assets/site/images/solution_info@2x.png') }}">
                    <img src="{{ asset('assets/site/images/info_1.png') }}" width="100%" alt="info" />


                    <div class="solution__overlay--content">
                        <div class="solution__overlay--title">
                            EUC (END USER COMPUTING)
                        </div>
                        <div class="solution__overlay--text">
                            We provide a myriad of End User Computing solutions targeting at spurring opportunities and minimising risk for SMEs. Our rental scheme protects against business uncertainty, allowing enterprises to rent desktop computers from as low as RM1.50 per day. This allows them the flexibility to scale up and down quickly and easily, without having to worry about heavy start-up capital investment.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
