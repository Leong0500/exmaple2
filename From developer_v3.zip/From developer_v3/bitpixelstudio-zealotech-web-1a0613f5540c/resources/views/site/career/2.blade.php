@extends('site.layouts.app')
@section('pageTitle', 'IT Engineer')

@section('content')
    <section>
        <div class="banner__img">
            <img src="{{ secure_asset('assets/site/images/banner_about@2x.png') }}"  alt="career__banner" />
            <div class="overlay__wrapper--home">
                <div class="overlay__banner--title">
                    IT Engineer
                </div>
            </div>
        </div>
    </section>

    <section style="background-color: #f5f5f5">
        <div class="container">
            <div class="inner__wrapper section__padding">
                <div class="">

                    <div class="career__position text-uppercase px-0">
                        IT Engineer
                    </div>
                    <p>&nbsp;</p>
                    <div class="career__text px-0">
                        <p class="font__hnBold">Job Description</p>

                        <ul style="padding-left: 20px">
                            <li>Installation, troubleshoot and configure of PC, Notebooks, Printers, Scanners hardware components.</li>
                            <li>Installation, troubleshoot and configure of Microsoft Window Operating system and Microsoft applications in the Desktop and Notebook.</li>
                            <li>Installation and troubleshoot anti-virus software, patches and hot-fixes for MS or other applications.</li>
                            <li>Data analysis.</li>
                            <li>Creation of new pc image, support deployment and software agents</li>
                        </ul>
                        <p>3 full time position available, Intern are also welcome to apply </p>
                        <p>&nbsp;</p>
                        <p class="font__hnBold">Job Requirements:</p>


                        <ul style="padding-left: 20px">
                            <li>Candidate must possess at least a Bachelor’s Degree, Post Graduate Diploma, Professional Degree, Computer Science/Information Technology, Engineering (Computer/Telecommunication) or equivalent.</li>
                            <li>Required language(s): Bahasa Malaysia, English</li>
                            <li>Ability to work independently with minimum supervision.</li>
                            <li>Able to handle multitask.</li>
                            <li>Fast learner and able to work under pressure.</li>
                            <li>Possess technical certification will have added advantage</li>
                            <li>Possess own car and willing to travel</li>
                        </ul>


                        <p style="margin-top: 48px;">Interested candidates are invited to email your latest resume to <a href="mailto:hr@zealotechsolution.com">hr@zealotechsolution.com</a>. Only shortlisted candidate will be notified.</p>


                    </div>


                </div>
            </div>
        </div>
    </section>
@endsection
