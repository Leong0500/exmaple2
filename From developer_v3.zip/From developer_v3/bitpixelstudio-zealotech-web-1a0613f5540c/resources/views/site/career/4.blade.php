@extends('site.layouts.app')
@section('pageTitle', 'System Engineer')

@section('content')
    <section>
        <div class="banner__img">
            <img src="{{ secure_asset('assets/site/images/banner_about@2x.png') }}" alt="career__banner" />
            <div class="overlay__wrapper--home">
                <div class="overlay__banner--title">
                    System Engineer
                </div>
            </div>
        </div>
    </section>

    <section style="background-color: #f5f5f5">
        <div class="container">
            <div class="inner__wrapper section__padding">
                <div class="">

                    <div class="career__position text-uppercase px-0">
                        System Engineer
                    </div>
                    <p>&nbsp;</p>
                    <div class="career__text px-0">
                        <p class="font__hnBold">Job Description</p>

                        <ul style="padding-left: 20px">
                            <li>Provides technical advice and support to Level 1 and 2 Engineers</li>
                            <li>Customer support on-site and off-site</li>
                            <li>Provides remote troubleshooting if needed</li>
                            <li>Attends to high severity incidents on and off-site</li>
                            <li>Prepares and follow-up on incident reports if any</li>
                            <li>Updates incident tickets in a timely manner in Field Service Management System to meet contractual Service Level Agreements</li>
                            <li>Reviews and submits incident reports in a timely manner</li>
                            <li>Coordinates with the technical team to prepare problem management reports</li>
                            <li>Reviews problem management reports</li>
                            <li>Monitors and ensures problem management reports are submitted in a timely manner</li>
                            <li>Leads problem management and resolution in the support products.</li>
                            <li>Leads project implementation</li>
                            <li>Reviews project scope, Pre-Implementation Validation (PIV) and prepares project deployment checklist</li>
                            <li>Ensures project timely completion.</li>
                            <li>Plans and reviews implementation timeline with project manager.</li>
                            <li>Develops design configuration documentation</li>
                            <li>Captures and updates project implementation technical issues for references</li>
                            <li>Assumes the Project Technical Lead role when required</li>
                            <li>Submits timesheet to reporting manager</li>
                            <li>Provides scope of work and man-days to pre-sales & sales teams (if required)</li>
                            <li>Reviews and highlights project deployment risks</li>
                            <li>Conducts technical sharing with Level 1 and 2 engineers</li>
                        </ul>
                        <p>2 full time position available </p>
                        <p>&nbsp;</p>
                        <p class="font__hnBold">Job Requirements:</p>


                        <ul style="padding-left: 20px">
                            <li>Candidate must possess at least a Bachelor’s Degree, Post Graduate Diploma, Professional Degree, Computer Science/Information Technology, Engineering (Computer/Telecommunication) or equivalent.</li>
                            <li>Minimum 3 to 5 years related working experience in an IT related environment</li>
                            <li>Required language(s): Bahasa Malaysia, English</li>
                            <li>Ability to work independently with minimum supervision.</li>
                            <li>Preferably Senior Executives specializing in IT/Computer Network/ System/Database Admin or equivalent.</li>
                            <li>Able to handle multitask.</li>
                            <li>Fast learner and able to work under pressure.</li>
                            <li>Possess technical certification such as MCSA, MCSE, MCDBA, Cisco, Sun etc. will have added advantage</li>
                            <li>Possess own car and willing to travel</li>
                        </ul>

                        <p style="margin-top: 48px;">Interested candidates are invited to email your latest resume to <a href="mailto:hr@zealotechsolution.com">hr@zealotechsolution.com</a>. Only shortlisted candidate will be notified.</p>


                    </div>

                </div>
            </div>
        </div>
    </section>
@endsection
