@extends('site.layouts.app')
@section('pageTitle', 'Accountant')


@section('content')
    <section>
        <div class="banner__img">
            <img src="{{ secure_asset('assets/site/images/banner_about@2x.png') }}" alt="career__banner" />
            <div class="overlay__wrapper--home">
                <div class="overlay__banner--title">
                    Accountant
                </div>
            </div>
        </div>
    </section>

    <section style="background-color: #f5f5f5">
        <div class="container">
            <div class="inner__wrapper section__padding">
                <div class="">

                    <div class="career__position text-uppercase px-0">
                        Accountant
                    </div>
                    <p>&nbsp;</p>
                    <div class="career__text px-0">
                        <p class="font__hnBold">Job Description</p>

                        <ul style="padding-left: 20px">
                            <li>Candidate must possess either a Bachelor’s Degree, Post Graduate Diploma, Professional Degree, Finance/Accountancy/Banking or equivalent.</li>
                            <li>At least 4 – 5 years working experience for Accountant are required for this position.</li>
                            <li>Preferably Senior specializing in Finance Corporate Finance / Investment / Treasury or equivalent.</li>
                            <li>Required skill(s): strong interpersonal skills, strong sense of urgency, results oriented, self-starter, a hands-on person and able to work independently.</li>
                            <li>Required language(s): Bahasa Malaysia, English</li>
                        </ul>
                        <p>&nbsp;</p>
                        <p class="font__hnBold">Job Requirements:</p>


                        <ul style="padding-left: 20px">
                            <li>Manage all taxation issues and ensure compliance with reporting and payment</li>
                            <li>Financial budgeting process, group consolidation and costing</li>
                            <li>Analyze all aspects of the financial performance and identify profit improvement opportunities</li>
                            <li>Liaison with external auditor, tax consultant and company secretary to ensure compliance with relevant legislations</li>
                        </ul>


                        <p style="margin-top: 48px;">Interested candidates are invited to email your latest resume to <a href="mailto:hr@zealotechsolution.com">hr@zealotechsolution.com</a>. Only shortlisted candidate will be notified.</p>

                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
