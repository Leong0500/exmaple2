@extends('site.layouts.app')
@section('pageTitle', 'Data Capturer')

@section('content')
    <section>
        <div class="banner__img">
            <img src="{{ secure_asset('assets/site/images/banner_about@2x.png') }}" alt="career__banner" />
            <div class="overlay__wrapper--home">
                <div class="overlay__banner--title">
                    Data Capturer
                </div>
            </div>
        </div>
    </section>

    <section style="background-color: #f5f5f5">
        <div class="container">
            <div class="inner__wrapper section__padding">
                <div class="">

                    <div class="career__position text-uppercase px-0">
                        Data Capturer
                    </div>
                    <p>&nbsp;</p>
                    <div class="career__text px-0">
                        <p class="font__hnBold">Job Description </p>

                        <ul style="padding-left: 20px">
                            <li>Capture data from available records into the required formats, databases, table, and spreadsheets. </li>
                            <li>Update registers and statistics, backup and maintain records or files.</li>
                            <li>Knowledge of computer, ability to capture data, operate computer and collect stats.</li>
                        </ul>

                        <p>2 full time position available, Intern are also welcome to apply </p>
                        <p>&nbsp;</p>
                        <p class="font__hnBold">Job Requirements:</p>

                        <ul style="padding-left: 20px">
                            <li>Computer literate (Microsoft Windows, Excel and Word)</li>
                            <li>Ability to conduct research on the internet</li>
                            <li>Ability to work independently with minimum supervision.</li>
                            <li>Able to handle multitask.</li>
                            <li>Fast learner and able to work under pressure.</li>
                        </ul>


                        <p style="margin-top: 48px;">Interested candidates are invited to email your latest resume to <a href="mailto:hr@zealotechsolution.com">hr@zealotechsolution.com</a>. Only shortlisted candidate will be notified.</p>

                    </div>


                </div>
            </div>
        </div>
    </section>
@endsection
