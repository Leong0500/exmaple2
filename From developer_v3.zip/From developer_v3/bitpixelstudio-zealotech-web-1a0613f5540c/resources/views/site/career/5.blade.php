@extends('site.layouts.app')
@section('pageTitle', 'Sales Account Manager')


@section('content')
    <section>
        <div class="banner__img">
            <img src="{{ secure_asset('assets/site/images/banner_about@2x.png') }}" alt="career__banner" />
            <div class="overlay__wrapper--home">
                <div class="overlay__banner--title">
                    Sales Account Manager
                </div>
            </div>
        </div>
    </section>

    <section style="background-color: #f5f5f5">
        <div class="container">
            <div class="inner__wrapper section__padding">
                <div class="">

                    <div class="career__position text-uppercase px-0">
                        Sales Account Manager
                    </div>
                    <p>&nbsp;</p>
                    <div class="career__text px-0">
                        <p class="font__hnBold">Job Description</p>

                        <ul style="padding-left: 20px">
                            <li>Build strong relationships with the client at all management levels.</li>
                            <li>Ability to create strong business between Zealotech and the key accounts at all requested levels.</li>
                            <li>Manage key accounts sales related activities.</li>
                            <li>Seek new accounts and opportunities.</li>
                            <li>Perform sales and marketing activities with indoor sales executive.</li>
                            <li>Promote a range of niche IT products and services to clients</li>
                            <li>Establish productive, professional relationships with key personnel in assigned customer accounts</li>
                            <li>Work with internal team members to ensure consistent sales performance</li>
                            <li>Business report (monthly forecast, weekly commit, pipeline development)</li>
                            <li>Lead and oversee the team</li>
                        </ul>
                        <p>2 Full-Time position available. </p>
                        <p>&nbsp;</p>
                        <p class="font__hnBold">Job Requirements:</p>


                        <ul style="padding-left: 20px">
                            <li>Candidate must possess at least a Bachelor’s Degree, or 2 – 5 year(s) of related work experience in similar industry</li>
                            <li>Technical skills: Lead in customer conversation</li>
                            <li>Common business sense; highly assertive & persuasive</li>
                            <li>Strong presentation and good negotiation skills</li>
                            <li>Well versed in Microsoft Office (Excel, PowerPoint, Word)</li>
                            <li>Able to work with high performing team and fast pace working environment</li>
                            <li>Strong drive for sales and numbers</li>
                            <li>Strong leadership and people management skills</li>
                            <li>Prefer candidates that able to join immediately</li>
                        </ul>


                        <p style="margin-top: 48px;">Interested candidates are invited to email your latest resume to <a href="mailto:hr@zealotechsolution.com">hr@zealotechsolution.com</a>. Only shortlisted candidate will be notified.</p>


                    </div>

                </div>
            </div>
        </div>
    </section>
@endsection
