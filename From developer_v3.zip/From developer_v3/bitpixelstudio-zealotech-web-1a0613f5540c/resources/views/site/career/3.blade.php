@extends('site.layouts.app')
@section('pageTitle', 'Marketing Specialist')

@section('content')
    <section>
        <div class="banner__img">
            <img src="{{ secure_asset('assets/site/images/banner_about@2x.png') }}" alt="career__banner" />
            <div class="overlay__wrapper--home">
                <div class="overlay__banner--title">
                    Marketing Specialist
                </div>
            </div>
        </div>
    </section>

    <section style="background-color: #f5f5f5">
        <div class="container">
            <div class="inner__wrapper section__padding">
                <div class="">
                    <div class="career__position text-uppercase px-0">
                        Marketing Specialist
                    </div>
                    <p>&nbsp;</p>
                    <div class="career__text px-0">
                        <p class="font__hnBold">Job Description</p>

                        <ul style="padding-left: 20px">
                            <li>Develop, implement and manage marketing strategy.</li>
                            <li>Making decisions for websites, social media and online advertisement.</li>
                            <li>Develop new online marketing strategies.</li>
                            <li>Prepare and manage digital marketing budget.</li>
                            <li>Responsible for the format, features and design of the websites.</li>
                            <li>Monitor SEO and user engagement and suggest content optimization.</li>
                            <li>Implement strategy to grow the customer database including subscription and database acquisition.</li>
                            <li>Conduct photo and video editing on product.</li>
                        </ul>
                        <p>1 full time position available, Intern are also welcome to apply </p>
                        <p>&nbsp;</p>
                        <p class="font__hnBold">Job Requirements:</p>


                        <ul style="padding-left: 20px">
                            <li>Strong interest in marketing. </li>
                            <li>Good knowledge of current marketing trend </li>
                            <li>Creative thinker and problem-solving skills </li>
                        </ul>


                        <p style="margin-top: 48px;">Interested candidates are invited to email your latest resume to <a href="mailto:hr@zealotechsolution.com">hr@zealotechsolution.com</a>. Only shortlisted candidate will be notified.</p>

                    </div>


                </div>
            </div>
        </div>
    </section>
@endsection
