@extends('site.layouts.app')
@section('pageTitle', 'Alliance')
@php
    $menuTag = 'alliance';
@endphp


@section('content')
    <section>
        <div class="banner__img">

            <img src="{{ asset('assets/site/images/banner_alliance@2x.png') }}" alt="alliance_banner" />

            <div class="overlay__wrapper--home">
                <h1 class="overlay__banner--title">
                    Alliance
                </h1>
            </div>
        </div>
    </section>

    <section class="section__padding">
        <div class="container">
            <div class="inner__wrapper">
                <div class="sub__wrapper">
                    <div class="sub__text">
                        To give our customers the very best solutions, we work closely with a global network of the top names within various fields of IT. These include renowned corporations such as Microsoft, Cisco, Broadcom, Nutanix, Extreme Networks, Trend Micro, Sophos, Veritas, Fortinet, Dell Technologies, Veeam, Huawei, VMWare, Kemp, Hewlett Packard Enterprise, Barracuda, Lenovo, Citrix, APC, Fireeye and more.
                    </div>
                </div>
            </div>

            <div class="inner__wrapper">
                <div class="row mt-5">
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-01.png') }}" alt="alliance_0"/>
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-02.png') }}" alt="alliance_1" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-03.png') }}" alt="alliance_2" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-04.png') }}" alt="alliance_3" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-05.png') }}" alt="alliance_4" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-06.png') }}" alt="alliance_5" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-07.png') }}" alt="alliance_6" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-08.png') }}" alt="alliance_7" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-09.png') }}" alt="alliance_8" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-10.png') }}" alt="alliance_9" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-11.png') }}" alt="alliance_10" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-12.png') }}" alt="alliance_11" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-13.png') }}" alt="alliance_12" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-14.png') }}" alt="alliance_13" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-15.png') }}" alt="alliance_14" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-16.png') }}" alt="alliance_15" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-17.png') }}" alt="alliance_16" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-18.png') }}" alt="alliance_17" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-19.png') }}" alt="alliance_18" />
                    </div>
                    <div class="col-4 col-md-3 alliance__img">
                        <img src="{{ asset('assets/site/images/alliance/Logo-20.png') }}" alt="alliance_19" />
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
