@extends('site.layouts.app')
@section('pageTitle', 'About Us')
@php
    $menuTag = 'about';
@endphp


@section('content')

    <section>
        <div class="banner__img">

            <img src="{{ asset('assets/site/images/banner_about@2x.png') }}" alt="about_banner"/>

            <div class="overlay__wrapper--home">
                <h1 class="overlay__banner--title">
                    About Us
                </h1>
            </div>
        </div>
    </section>

    <section class="section__padding">
        <div class="container">
            <div class="inner__wrapper">
                <div class="sub__wrapper">
                    <div class="sub__text">
                        Zealotech Solution is an IT solutions provider based in Kuala Lumpur, Malaysia and Singapore. Founded by a passionate team of veteran engineers with over 25 years of IT industry experience, we specialise in cutting-edge IT solutions for both large and small businesses.
                    </div>

                    <div class="sub__text">
                        At Zealotech, we cater for a wide scale of businesses, ranging from large multinational corporations to small enterprises and startups. We draw insights from our own simple beginnings in basic IT management, progressing over the years into highly complex infrastructure suited for small and large companies alike.
                    </div>

                    <div class="sub__text">
                        In every project, we take the time to understand our clients’ specific needs and expectations, hence delivering best-in-class integrated solutions that simply work. Ultimately, our technology doesn’t just solve problems for businesses, but serves as a gateway to greater heights and limitless possibilities.
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section>
        <div class="position-relative">

            <img src="{{ asset('assets/site/images/about_1@2x.png') }}" alt="img_about" style="width: 100%" />

            <div class="about__overlay--wrapper">


                <div class="about__different--title">
                    <div class="section__title--home text-center">
                        The Zealotech Difference
                    </div>
                </div>

                <div class="about__overlay--box">
                    <div class="about__overlay--item">
                        <div class="about__overlay--img">

                            <img src="{{ asset('assets/site/images/icons/about_icon_1@2x.png') }}" alt="about_icon" />

                        </div>
                        <div class="about__overlay--content">
                            <div class="about__overlay--title">
                                WE DELIVER RESULTS
                            </div>
                            <div class="about__overlay--text">
                                On time, on budget, on brief. We will always go the extra mile to make sure that our clients’ expectations are met in absolute excellence.
                            </div>
                        </div>
                    </div>

                    <div class="about__overlay--item about__overlay--item-reverse">
                        <div class="about__overlay--img">

                            <img src="{{ secure_asset('assets/site/images/icons/about_icon_2@2x.png') }}" alt="about_icon_2" />

                        </div>
                        <div class="about__overlay--content">
                            <div class="about__overlay--title">
                                WE ADD VALUE
                            </div>
                            <div class="about__overlay--text text__reverse">
                                Everything we do is geared towards helping our clients run their businesses more efficiently and effectively, and gain a competitive edge.
                            </div>
                        </div>
                    </div>

                    <div class="about__overlay--item">
                        <div class="about__overlay--img">

                            <img src="{{ asset('assets/site/images/icons/about_icon_3@2x.png') }}" alt="about_icon_3" />

                        </div>
                        <div class="about__overlay--content">
                            <div class="about__overlay--title">
                                WE WORK TOGETHER
                            </div>
                            <div class="about__overlay--text">
                                From day one of each project, we align our vision with the client to ensure a close understanding that sets the stage for rewarding long-term partnerships.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section>
        <div class="container">
            <div class="inner__wrapper section__padding">
                <div class="row">
                    <div class="col-12 text-center">
                        <div class="font__main">
                            Our commitment is to not only deliver quality for our clients, but to innovate and up the game for <br>the entire IT industry through constant innovation.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>




@endsection
