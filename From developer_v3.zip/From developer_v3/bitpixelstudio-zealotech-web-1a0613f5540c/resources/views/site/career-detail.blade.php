@extends('site.layouts.app')
@section('pageTitle', 'Career Details')


@section('content')
    <section>
        <div class="banner__img">
            <img src="{{ asset('assets/site/images/banner_about@2x.png') }}" alt="career_detail_banner" />
            <div class="overlay__wrapper--home">
                <h1 class="overlay__banner--title">
                    Career Detail
                </h1>
            </div>
        </div>
    </section>

    <section style="background-color: #f5f5f5">
        <div class="container">
            <div class="inner__wrapper section__padding">
                <div class="">
                    <div class="career__title px-0">
                        Career Title
                    </div>

                    <div class="career__position px-0">
                        FINANCE & ACCOUNTS EXECUTIVE
                    </div>

                    <div class="career__text px-0">
                        <p class="font__hnBold">Job Highlights</p>
                        - Multi-national Fortune 500 companies<br>
                        - Excellent career advancement opportunity<br>
                        - Excellent staff benefit & vibrant work culture<br>
                        <p>&nbsp;</p>
                        <p class="font__hnBold">Job Description</p>
                        Job Responsibilities:<br>
                        - Manage day to day sales accounting & finance functions.<br>
                        - Ensure account payable, bank reconciliation, etc are done accurately & effectively.<br>
                        - Perform creditors/account receivable reconciliation.<br>
                        - Perform month end sales closing & reporting.<br>
                        <p>&nbsp;</p>
                        <p class="font__hnBold">Job Requirements:</p>
                        - Candidate must possess at least a Diploma / Bachelor Degree in Finance / Accountancy or equivalent.<br>
                        - At least 3 years of working experience in the related field is required for this position.<br>
                        - Good analytical skill & highly dedicated to complete job task with accuracy & reliability.<br>
                        <p>&nbsp;</p>
                    </div>


                </div>
            </div>
        </div>
    </section>
@endsection
