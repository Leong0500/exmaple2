@extends('site.layouts.app')
@section('pageTitle', 'Thank You')
@php
    $menuTag = 'thank-you';
@endphp


@section('content')

    <section>
        <div class="banner__img">

            <img src="{{ asset('assets/site/images/banner_contact@2x.png') }}" alt="tq_banner" />

            <div class="overlay__wrapper--home">
                <h1 class="overlay__banner--title">
                    Enquiry
                </h1>
            </div>
        </div>
    </section>


    <div class="container section__padding">

        <div class="row">

            <div class="col-md-12 text-center">

                @if(session('message'))
                    <h4>{{ session('message') }}</h4>
                @endif

                <a href="{{ route('site.index') }}">Back to home</a>

            </div>

        </div>

    </div>
@endsection
