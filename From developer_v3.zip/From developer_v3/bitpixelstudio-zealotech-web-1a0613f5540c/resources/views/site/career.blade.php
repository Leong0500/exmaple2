@extends('site.layouts.app')
@section('pageTitle', 'Careers')


@section('content')
    <section>
        <div class="banner__img">
            <img src="{{ secure_asset('assets/site/images/banner_about@2x.png') }}" alt="career_banner" />
            <div class="overlay__wrapper--home">
                <h1 class="overlay__banner--title">
                    Career
                </h1>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="section__padding">
                <div class="row">
                    <div class="col-md-4">
                        <div class="career__body">
                            <a href="{{ route('site.career.1') }}">
                            <div class="career__content">
                                <div class="career__position text-uppercase">
                                    Data Capturer
                                </div>
                                <div class="career__text text-justify">

                                    {{ Str::words('Capture data from available records into the required formats, databases, table, and spreadsheets.Update registers and statistics, backup and maintain records or files. Knowledge of computer, ability to capture data, operate computer and collect stats.',25,'...') }}

                                </div>
                            </div>
                            </a>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="career__body">
                            <a href="{{ route('site.career.2') }}">
                                <div class="career__content">
                                    <div class="career__position text-uppercase">
                                        IT Engineer
                                    </div>
                                    <div class="career__text text-justify">
                                        {{ Str::words('Installation, troubleshoot and configure of PC, Notebooks, Printers, Scanners hardware components. Installation, troubleshoot and configure of Microsoft Window Operating system and Microsoft applications in the Desktop and Notebook.',20,'...') }}
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="career__body">
                            <a href="{{ route('site.career.3') }}">
                                <div class="career__content">
                                    <div class="career__position text-uppercase">
                                        Marketing Specialist
                                    </div>
                                    <div class="career__text text-justify">
                                        {{ Str::words('Develop, implement and manage marketing strategy.

                                        Making decisions for websites, social media and online advertisement.

                                        Develop new online marketing strategies',20,'...') }}
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>


                    <div class="col-md-4">
                        <div class="career__body">
                            <a href="{{ route('site.career.4') }}">
                                <div class="career__content">

                                    <div class="career__position text-uppercase">
                                        System Engineer
                                    </div>
                                    <div class="career__text text-justify">
                                        {{ Str::words('Provides technical advice and support to Level 1 and 2 Engineers
                                        Customer support on-site and off-site
                                        Provides remote troubleshooting if needed
                                        Attends to high severity incidents on and off-site
                                        Prepares and follow-up on incident reports if any
                                        Updates incident tickets in a timely manner in Field Service Management System to meet contractual Service Level Agreements ',20,'...') }}
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>


                    <div class="col-md-4">
                        <div class="career__body">
                            <a href="{{ route('site.career.5') }}">
                                <div class="career__content">
                                    <div class="career__position text-uppercase">
                                        Sales Account Manager
                                    </div>
                                    <div class="career__text text-justify">
                                        {{ Str::words('Build strong relationships with the client at all management levels.
                                        Ability to create strong business between Zealotech and the key accounts at all requested levels.
                                        Manage key accounts sales related activities.
                                        Seek new accounts and opportunities.  ',20,'...') }}
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>


                    <div class="col-md-4">
                        <div class="career__body">
                            <a href="{{ route('site.career.6') }}">
                                <div class="career__content">
                                    <div class="career__position text-uppercase">
                                        Accountant
                                    </div>
                                    <div class="career__text text-justify">
                                        {{ Str::words('Preferably Senior specializing in Finance Corporate Finance / Investment / Treasury or equivalent. At least 4–5 years working experience for Accountant are required for this position. ',20,'...') }}
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>




                </div>
            </div>
        </div>
    </section>
@endsection
