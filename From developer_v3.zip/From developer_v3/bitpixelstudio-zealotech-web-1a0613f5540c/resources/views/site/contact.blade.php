@extends('site.layouts.app')
@section('pageTitle', 'Contact Us')
@php
    $menuTag = 'contact';
@endphp


@section('content')

    <section>
        <div class="banner__img">

            <img src="{{ secure_asset('assets/site/images/banner_contact@2x.png') }}" alt="contact_banner" />

            <div class="overlay__wrapper--home">
                <h1 class="overlay__banner--title">
                    Contact Us
                </h1>
            </div>
        </div>
    </section>

    <section class="section__padding">
        <div class="container">
            <div class="inner__wrapper">
                <div class="row flex-row-reverse">

                    <div class="col-md-12 mb-3">
                        <div id="my">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.1452367619645!2d101.55556331487612!3d3.055780354571401!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc4d17eb12bbb9%3A0xd4622faa1aa40ec9!2sZealotech%20Solution%20(M)%20Sdn.%20Bhd.!5e0!3m2!1sen!2smy!4v1614063136052!5m2!1sen!2smy" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                        <div id="sg" class="d-none">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3988.6758689015487!2d103.93097931487918!3d1.3711668618882291!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31da3dbae1e2aa75%3A0x279396d6a4ccd051!2sZealotech%20Solution%20Pte.%20Ltd.!5e0!3m2!1sen!2smy!4v1614175528487!5m2!1sen!2smy" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                    </div>

                    <div class="col-md-7">

                        <form class="contact__form" method="post" action="{{ route('site.enquiry') }}">
                                @csrf
                                <div class="contact__form--title">request for call</div>

                                <div class="row">
                                    <div class="form-group col-md-6">
                                        <input type="text" class="contact__input" name="name" id="name" value="{{ old('name') }}" placeholder="Name" required>
                                        @error('name')
                                        <div class="message__error">{{ $message }}</div>
                                        @enderror
                                    </div>

                                    <div class="form-group col-md-6">
                                        <input type="text" class="contact__input" name="phone" id="phone" value="{{ old('phone') }}" placeholder="Phone" required>
                                        @error('phone')
                                        <div class="message__error">{{ $message }}</div>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-group">
                                    <input type="text" class="contact__input" name="email" id="email" value="{{ old('email') }}" placeholder="Email" required>
                                    @error('email')
                                    <div class="message__error">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="form-group">
                                    <textarea class="contact__input" rows="5" name="message" id="message" placeholder="Message" required>{{ old('message') }}</textarea>
                                    @error('message')
                                    <div class="message__error">{{ $message }}</div>
                                    @enderror
                                </div>

                                <div class="form__action text-right">
                                    <button type="submit" class="btn btn__submit">Send</button>
                                </div>
                        </form>

                    </div>
                    <div class="col-md-5">
                        <div class="bg__main w-100">
                            <div class="text-right mb-3">
                                <img src="{{ asset('assets/site/images/icons/marker_reverse@2x.png') }}" alt="" />
                            </div>

                            <div class="contact__info" id="my_c">
                                <p class="contact__address">MALAYSIA</p>

                                <p class="font__bold">Zealotech Solution (M) Sdn. Bhd.</p>

                                <p class="contact__address">
                                    Unit 20-01, Level 20, Menara Geno,<br>
                                    Jalan Subang Mas, 47620 Subang Jaya,<br>
                                    Selangor Darul Ehsan, Malaysia.
                                </p>
                            </div>

                            <div class="contact__info" id="sg_c">
                                <p class="contact__address">SINGAPORE</p>

                                <p class="font__bold">Zealotech Solution Pte. Ltd.</p>

                                <p class="contact__address">
                                    1 Tampines North Drive,<br>
                                    1, #06-08, T-Space,<br>
                                    Singapore 528559
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection

@push('scripts')
    <script>
        $(document).ready(function (){
            $('#my_c').on('click',function (){
                $('#my').removeClass('d-none');
                $('#sg').addClass('d-none');
            });

            $('#sg_c').on('click',function (){
                $('#sg').removeClass('d-none');
                $('#my').addClass('d-none');
            });
        });
    </script>
@endpush
