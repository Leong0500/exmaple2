
<footer class="bg__img font__white" style="background-image: url('{{ secure_asset('assets/site/images/footer_img@2x.png') }}')" alt="bg_footer">

    <div class="container">
        <div class="inner__wrapper">
            <div class="row">
                <div class="col-md-6">
                    <div class="footer__logo">

                        <img src="{{ asset('assets/site/images/logo/logo_white@2x.png') }}" alt="logo_footer" />

                    </div>
                    <div class="footer__text">
                        <h6>Zealotech Solution (M) Sdn. Bhd.</h6>
                        <h6>Zealotech Solution Pte. Ltd.</h6>
                    </div>

                    <div class="links__wrapper">
                        <span class="links__title">
                            Quick Link
                        </span>
                        <div class="links__link">
                            <div class="row">
                                <div class="col-6 link"><a href="{{ route('site.index') }}">Home</a></div>
                                <div class="col-6 link"><a href="{{ route('site.career') }}">Careers</a></div>
                                <div class="col-6 link"><a href="{{ route('site.about') }}">About Us</a></div>
                                <div class="col-6 link"><a href="{{ route('site.solution') }}">Solutions</a></div>
                                <div class="col-6 link"><a href="{{ route('site.alliance') }}">Alliance</a></div>
                                <div class="col-6 link"><a href="{{ route('site.contact') }}">Contact Us</a></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 d-flex flex-wrap align-content-center">
                    <div class="pt-5 mt-3"></div>
                    <div class="social__wrapper">
                        <div class="row">
                            <div class="col-12">
                                <div class="social">
                                    <img alt="email_logo" src="{{ asset('assets/site/images/icons/email@2x.png') }}" class="social__img" />

                                    <div class="social__text"><a href="mailto:zCare@zealotechsolution.com">zCare@zealotechsolution.com</a></div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="social">
                                    <img alt="phone_logo" src="{{ asset('assets/site/images/icons/phone@2x.png') }}" class="social__img" />

                                    <div class="social__text"><a href="tel:+603 5888 4515">+603 5888 4515</a></div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="social">
                                    <img alt="fb_logo" src="{{ asset('assets/site/images/icons/facebook@2x.png') }}" class="social__img" />

                                    <div class="social__text"><a href="https://www.facebook.com/zealotech">Zealotech</a></div>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="social">
                                    <img alt="whatsapp_logo" src="{{ asset('assets/site/images/icons/whatsapp@2x.png') }}" class="social__img" />

                                    <div class="social__text"><a href="https://wa.me/60358884515">+603 5888 4515</a></div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="copyright__wrapper">
                        <p>© Copyright {{ today()->format('Y') }}. All Rights Reserved by Zealotech Solution.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
