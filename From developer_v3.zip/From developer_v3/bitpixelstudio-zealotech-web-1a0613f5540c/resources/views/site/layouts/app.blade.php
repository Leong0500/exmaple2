<!doctype html>
<html lang="en">
<head>
    <title>@yield('pageTitle') | {{ config('app.name') }}</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="keywords" content="technology, hosting, web, cloud, enterprise">
    <meta name="description" content="Zealotech specialises in IT solutions that take businesses to the next level">
    <meta name="author" content="Bit Pixel Studio PLT">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="icon" href="{{ asset('assets/site/images/logo/logo.ico') }}">
    <link rel="apple-touch-icon" href="{{ asset('assets/site/images/logo/logo.ico') }}">
    <link rel="apple-touch-startup-image" href="{{ asset('assets/site/images/logo/logo.ico') }}">

    <meta property="og:url"                content="{{ route('site.index') }}" />
    <meta property="og:type"               content="website" />
    <meta property="og:title"              content="{{ config('app.name') }}" />
    <meta property="og:description"        content="Zealotech specialises in IT solutions that take businesses to the next level." />
    <meta property="og:image"              content="" />

    @include('site.layouts.styles')

</head>
<body>

@include('site.layouts.header')

<main>
    @yield('content')
</main>


@include('site.layouts.footer')
@include('site.layouts.scripts')

</body>
</html>
