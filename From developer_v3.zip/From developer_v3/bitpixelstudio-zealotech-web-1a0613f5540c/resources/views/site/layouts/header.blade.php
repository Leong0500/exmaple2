<header>
    <div class="container">
        <div class="inner__wrapper">
            <nav class="navbar">
                <div class="logo__wrapper">
                    <a href="{{ route('site.index') }}">

                        <img src="{{ asset('assets/site/images/logo/logo_main@2x.png') }}" alt="zealotech__logo" />

                    </a>
                </div>

                <div class="menu__wrapper">
                    <ul class="menu__list">
                        <li class="menu__item">
                            <a href="{{ route('site.index') }}" class="@if(isset($menuTag) && $menuTag == 'home') active @endif">Home</a>
                        </li>
                        <li class="menu__item">
                            <a href="{{ route('site.about') }}" class="@if(isset($menuTag) && $menuTag == 'about') active @endif">About Us</a>
                        </li>
                        <li class="menu__item">
                            <a href="{{ route('site.solution') }}" class="@if(isset($menuTag) && $menuTag == 'solution') active @endif">Solutions</a>
                        </li>
                        <li class="menu__item">
                            <a href="{{ route('site.alliance') }}" class="@if(isset($menuTag) && $menuTag == 'alliance') active @endif">Alliance</a>
                        </li>
                        <li class="menu__item">
                            <a href="{{ route('site.contact') }}" class="@if(isset($menuTag) && $menuTag == 'contact') active @endif">Contact</a>
                        </li>

                        <li class="menu__item menu__item--mobile">
                            <a href="javascript:;" id="mobileMenu"><i class="fas fa-bars"></i></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>
</header>

<div class="mobile__menu--wrapper animate__animated animate__fadeIn-9 d-none">
    <div id="mobileMenuClose" class="btn__close">x</div>
    <ul class="mobile__menu--list">
        <li class="mobile__menu--item">
            <a href="{{ route('site.index') }}" class="@if(isset($menuTag) && $menuTag == 'home') active @endif">Home</a>
        </li>
        <li class="mobile__menu--item">
            <a href="{{ route('site.about') }}" class="@if(isset($menuTag) && $menuTag == 'about') active @endif">About Us</a>
        </li>
        <li class="mobile__menu--item">
            <a href="{{ route('site.solution') }}" class="@if(isset($menuTag) && $menuTag == 'solution') active @endif">Solutions</a>
        </li>
        <li class="mobile__menu--item">
            <a href="{{ route('site.alliance') }}" class="@if(isset($menuTag) && $menuTag == 'alliance') active @endif">Alliance</a>
        </li>
        <li class="mobile__menu--item">
            <a href="{{ route('site.contact') }}" class="@if(isset($menuTag) && $menuTag == 'contact') active @endif">Contact</a>
        </li>
    </ul>
</div>
