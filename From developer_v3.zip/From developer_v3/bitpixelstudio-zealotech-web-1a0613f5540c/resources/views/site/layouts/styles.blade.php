<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" type="text/css"/>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css" >
<link rel="stylesheet" href="{{ asset('assets/site/css/animate.css') }}" type="text/css">
<link rel="stylesheet" href="{{ asset('assets/site/css/style.css') }}" type="text/css">
<link rel="stylesheet" href="{{ asset('assets/site/css/responsive.css') }}" type="text/css">
<link rel="stylesheet" href="{{ asset('assets/site/css/font.css') }}" type="text/css">
