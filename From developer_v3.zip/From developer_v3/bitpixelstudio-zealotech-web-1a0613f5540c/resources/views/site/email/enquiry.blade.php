<html lang="en">
    <head>
        <title>New Enquiry</title>
    </head>
<body>

<h4>New Enquiry From Website</h4>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
    <tbody>
    <tr>
        <td>Name :</td>
        <td>{{ $name }}</td>
    </tr>

    <tr>
        <td>Email :</td>
        <td>{{ $email }}</td>
    </tr>

    <tr>
        <td>Contact :</td>
        <td>{{ $phone }}</td>
    </tr>

    <tr>
        <td>Message :</td>
        <td>{{ $remark }}</td>
    </tr>
    </tbody>
</table>


</body>
</html>




