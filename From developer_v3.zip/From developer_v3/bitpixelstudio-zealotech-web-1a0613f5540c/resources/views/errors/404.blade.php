@extends('site.layouts.app')
@section('pageTitle', '404 Not Found')
@php
    $menuTag = 'error';
@endphp


@section('content')

    <section>
        <div class="banner__img">
            <img src="{{ asset('assets/site/images/banner_contact@2x.png') }}" alt="" />
            <div class="overlay__wrapper--home">
                <div class="overlay__banner--title">
                    404 Not Found
                </div>
            </div>
        </div>
    </section>



    <section class="section__padding">
        <div class="container">
            <div class="inner__wrapper">
                <div class="row flex-row-reverse">


                    <div class="col-md-12">
                        <h4>Page Not Found</h4>

                        <p style="margin-top: 48px;"><a href="{{ route('site.index') }}">Back to Home</a></p>
                    </div>


                </div>
            </div>
        </div>
    </section>


@endsection
